create view PROGRESS_STUDENT
    as select NAME, avg(NOTE)[AVGNOTE]
    from PROGRESS join STUDENT S on S.IDSTUDENT = PROGRESS.IDSTUDENT
group by NAME
go

