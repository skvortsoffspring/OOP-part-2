create view Academic
    as select
        TEACHER_NAME,
              GENDER,
              PULPIT
from TEACHER
go

