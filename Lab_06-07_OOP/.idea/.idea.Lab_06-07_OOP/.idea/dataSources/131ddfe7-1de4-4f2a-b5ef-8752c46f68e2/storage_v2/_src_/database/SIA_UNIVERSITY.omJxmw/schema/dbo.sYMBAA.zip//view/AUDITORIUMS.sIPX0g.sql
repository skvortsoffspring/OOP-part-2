create view AUDITORIUMS
    as select
        AUDITORIUM_NAME,
        AUDITORIUM_TYPE
from AUDITORIUM
where AUDITORIUM_TYPE = N'ЛК'
go

