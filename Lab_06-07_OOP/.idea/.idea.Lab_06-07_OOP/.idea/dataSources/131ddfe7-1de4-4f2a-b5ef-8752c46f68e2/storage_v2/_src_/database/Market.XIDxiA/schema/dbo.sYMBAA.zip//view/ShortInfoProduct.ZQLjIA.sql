create view ShortInfoProduct
    as select ProductCategory,
              ProductName,
              ProductLongDesc,
              ProductPrice
from products
where ProductPrice != 0 with check option
go

