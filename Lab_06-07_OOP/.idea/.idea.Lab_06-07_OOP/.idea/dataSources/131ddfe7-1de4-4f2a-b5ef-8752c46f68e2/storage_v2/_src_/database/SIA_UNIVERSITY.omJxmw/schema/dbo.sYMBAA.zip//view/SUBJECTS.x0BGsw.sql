create view SUBJECTS
    as select top 100
        SUBJECT,
        SUBJECT_NAME
from SUBJECT
order by SUBJECT
go

