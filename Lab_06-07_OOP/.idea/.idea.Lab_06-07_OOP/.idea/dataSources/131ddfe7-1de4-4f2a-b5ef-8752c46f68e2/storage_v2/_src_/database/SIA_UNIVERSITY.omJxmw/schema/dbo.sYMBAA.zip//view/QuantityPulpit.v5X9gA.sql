create view QuantityPulpit with schemabinding
    as select F.FACULTY_NAME,
              count(*)[CountFaculty]
from dbo.FACULTY F join dbo.PULPIT P on F.FACULTY = P.FACULTY
group by F.FACULTY_NAME
go

