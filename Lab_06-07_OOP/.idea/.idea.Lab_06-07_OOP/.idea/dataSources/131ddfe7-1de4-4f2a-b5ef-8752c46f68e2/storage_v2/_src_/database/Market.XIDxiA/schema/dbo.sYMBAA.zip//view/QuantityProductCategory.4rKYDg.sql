create view QuantityProductCategory with schemabinding
    as select CategoryName,
              count(*)[QuantityProducts]
from dbo.products P join dbo.productcategories P2 on P2.CategoryID = P.ProductCategory
group by CategoryName
go

